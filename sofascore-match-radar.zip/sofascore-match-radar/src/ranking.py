from __future__ import annotations

import math
import re
from collections import defaultdict, deque
from datetime import datetime
from typing import Any

from .config import RIVALRIES


def _norm(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


_RIVALRY_KEYS = {frozenset((_norm(a), _norm(b))) for a, b in RIVALRIES}


def _is_rivalry(home: str, away: str) -> bool:
    return frozenset((_norm(home), _norm(away))) in _RIVALRY_KEYS


def build_team_context(events: list[dict[str, Any]], standings: list[dict[str, Any]]) -> dict[int, dict[str, float]]:
    ctx: dict[int, dict[str, float]] = defaultdict(lambda: {
        "position": 20.0, "points": 0.0, "played": 0.0,
        "form_points": 0.0, "goals_for_recent": 0.0, "goals_against_recent": 0.0,
    })
    for row in standings:
        team_id = row.get("team", {}).get("id")
        if team_id is None:
            continue
        ctx[int(team_id)].update({
            "position": float(row.get("position", 20)),
            "points": float(row.get("points", 0)),
            "played": float(row.get("matches", 0)),
        })

    recent: dict[int, deque[tuple[int, int, int]]] = defaultdict(lambda: deque(maxlen=5))
    completed = sorted(
        [e for e in events if e.get("status", {}).get("type") == "finished"],
        key=lambda e: int(e.get("startTimestamp", 0)),
    )
    for event in completed:
        h = event.get("homeTeam", {}).get("id")
        a = event.get("awayTeam", {}).get("id")
        hs = event.get("homeScore", {}).get("current")
        aws = event.get("awayScore", {}).get("current")
        if None in (h, a, hs, aws):
            continue
        hp = 3 if hs > aws else 1 if hs == aws else 0
        ap = 3 if aws > hs else 1 if hs == aws else 0
        recent[int(h)].append((hp, int(hs), int(aws)))
        recent[int(a)].append((ap, int(aws), int(hs)))

    for team_id, games in recent.items():
        if games:
            ctx[team_id]["form_points"] = sum(g[0] for g in games) / (3 * len(games))
            ctx[team_id]["goals_for_recent"] = sum(g[1] for g in games) / len(games)
            ctx[team_id]["goals_against_recent"] = sum(g[2] for g in games) / len(games)
    return ctx


def score_event(event: dict[str, Any], ctx: dict[int, dict[str, float]], league_size: int) -> tuple[float, list[str]]:
    home = event.get("homeTeam", {})
    away = event.get("awayTeam", {})
    h = ctx.get(int(home.get("id", -1)), {})
    a = ctx.get(int(away.get("id", -1)), {})
    hp, ap = h.get("position", league_size), a.get("position", league_size)

    # 1) Qualità: premia squadre in alto in classifica.
    quality = 1 - ((hp + ap - 2) / max(2 * (league_size - 1), 1))
    # 2) Equilibrio: una partita tra squadre vicine è meno prevedibile.
    balance = 1 - min(abs(hp - ap) / max(league_size - 1, 1), 1)
    # 3) Forma: premia squadre entrambe in buon momento.
    form = (h.get("form_points", 0) + a.get("form_points", 0)) / 2
    # 4) Potenziale gol: normalizzato attorno a 3.2 gol combinati recenti.
    goal_raw = h.get("goals_for_recent", 0) + a.get("goals_for_recent", 0)
    goals = min(goal_raw / 3.2, 1)
    # 5) Pressione classifica: top clash o zona europea/salvezza ravvicinata.
    top_clash = 1.0 if hp <= 6 and ap <= 6 else 0.0
    relegation_clash = 1.0 if hp >= league_size - 4 and ap >= league_size - 4 else 0.0
    stakes = max(top_clash, relegation_clash)
    derby = 1.0 if _is_rivalry(home.get("name", ""), away.get("name", "")) else 0.0

    value = 100 * (
        0.29 * quality + 0.23 * balance + 0.17 * form +
        0.13 * goals + 0.10 * stakes + 0.08 * derby
    )
    value = max(0, min(100, value))

    reasons: list[str] = []
    if quality >= 0.72: reasons.append("squadre di alta classifica")
    if balance >= 0.78: reasons.append("sfida molto equilibrata")
    if form >= 0.65: reasons.append("buona forma recente")
    if goals >= 0.72: reasons.append("alto potenziale offensivo")
    if top_clash: reasons.append("scontro diretto europeo/titolo")
    if relegation_clash: reasons.append("scontro salvezza")
    if derby: reasons.append("rivalità/derby")
    if not reasons: reasons.append("profilo complessivo interessante")
    return round(value, 1), reasons[:3]


def ranked_upcoming(events: list[dict[str, Any]], standings: list[dict[str, Any]], now_ts: int) -> list[dict[str, Any]]:
    ctx = build_team_context(events, standings)
    league_size = max(len(standings), 18)
    output = []
    for event in events:
        if int(event.get("startTimestamp", 0)) < now_ts:
            continue
        if event.get("status", {}).get("type") not in {"notstarted", "postponed"}:
            continue
        score, reasons = score_event(event, ctx, league_size)
        output.append({"event": event, "interest": score, "reasons": reasons})
    return sorted(output, key=lambda x: (-x["interest"], x["event"].get("startTimestamp", 0)))
