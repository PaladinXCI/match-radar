from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import requests


class SofaScoreError(RuntimeError):
    pass


@dataclass
class SofaScoreClient:
    base_url: str = "https://www.sofascore.com/api/v1"
    timeout: int = 15
    min_interval: float = 0.35

    def __post_init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "MatchRadar/0.1 (personal dashboard; respectful polling)",
            "Accept": "application/json",
        })
        self._last_request = 0.0

    def _get(self, path: str) -> dict[str, Any]:
        elapsed = time.monotonic() - self._last_request
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        url = f"{self.base_url}{path}"
        try:
            response = self.session.get(url, timeout=self.timeout)
            self._last_request = time.monotonic()
            response.raise_for_status()
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            raise SofaScoreError(f"Errore SofaScore su {path}: {exc}") from exc

    def current_season(self, tournament_id: int) -> dict[str, Any]:
        data = self._get(f"/unique-tournament/{tournament_id}/seasons")
        seasons = data.get("seasons", [])
        if not seasons:
            raise SofaScoreError("Nessuna stagione trovata")
        # L'endpoint normalmente restituisce la più recente per prima.
        return max(seasons, key=lambda s: int(s.get("id", 0)))

    def standings(self, tournament_id: int, season_id: int) -> list[dict[str, Any]]:
        data = self._get(
            f"/unique-tournament/{tournament_id}/season/{season_id}/standings/total"
        )
        blocks = data.get("standings", [])
        if not blocks:
            return []
        return blocks[0].get("rows", [])

    def events_page(self, tournament_id: int, season_id: int, direction: str, page: int) -> dict[str, Any]:
        if direction not in {"last", "next"}:
            raise ValueError("direction deve essere 'last' o 'next'")
        return self._get(
            f"/unique-tournament/{tournament_id}/season/{season_id}/events/{direction}/{page}"
        )

    def all_events(self, tournament_id: int, season_id: int, max_pages: int = 30) -> list[dict[str, Any]]:
        by_id: dict[int, dict[str, Any]] = {}
        for direction in ("last", "next"):
            for page in range(max_pages):
                payload = self.events_page(tournament_id, season_id, direction, page)
                events = payload.get("events", [])
                for event in events:
                    event_id = event.get("id")
                    if event_id is not None:
                        by_id[int(event_id)] = event
                if not payload.get("hasNextPage", False):
                    break
        return sorted(by_id.values(), key=lambda e: int(e.get("startTimestamp", 0)))
