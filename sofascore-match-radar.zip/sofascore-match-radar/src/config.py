LEAGUES = {
    "Premier League": {"tournament_id": 17, "country": "Inghilterra"},
    "LaLiga": {"tournament_id": 8, "country": "Spagna"},
    "Serie A": {"tournament_id": 23, "country": "Italia"},
    "Bundesliga": {"tournament_id": 35, "country": "Germania"},
    "Ligue 1": {"tournament_id": 34, "country": "Francia"},
}

# Rivalità principali. I nomi vengono normalizzati e il matching è bidirezionale.
RIVALRIES = [
    ("Arsenal", "Tottenham Hotspur"), ("Liverpool", "Manchester United"),
    ("Manchester City", "Manchester United"), ("Chelsea", "Arsenal"),
    ("Real Madrid", "Barcelona"), ("Real Madrid", "Atletico Madrid"),
    ("Barcelona", "Espanyol"), ("Sevilla", "Real Betis"),
    ("Inter", "Milan"), ("Juventus", "Inter"), ("Roma", "Lazio"),
    ("Juventus", "Torino"), ("Napoli", "Roma"),
    ("Bayern Munich", "Borussia Dortmund"), ("Schalke 04", "Borussia Dortmund"),
    ("Hamburger SV", "Werder Bremen"),
    ("Paris Saint-Germain", "Olympique de Marseille"),
    ("Olympique Lyonnais", "Saint-Etienne"), ("Lille", "Lens"),
]
