from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from src.config import LEAGUES
from src.notifier import send_telegram, telegram_configured
from src.ranking import ranked_upcoming
from src.sofascore import SofaScoreClient, SofaScoreError

load_dotenv()
ROME = ZoneInfo("Europe/Rome")

st.set_page_config(page_title="Match Radar", page_icon="⚽", layout="wide")
st.title("⚽ Match Radar — Top 5 leghe")
st.caption("Le partite più interessanti da vedere, ordinate con un indice trasparente da 0 a 100.")

@st.cache_data(ttl=1800, show_spinner=False)
def load_league(name: str):
    cfg = LEAGUES[name]
    client = SofaScoreClient()
    season = client.current_season(cfg["tournament_id"])
    season_id = int(season["id"])
    events = client.all_events(cfg["tournament_id"], season_id)
    standings = client.standings(cfg["tournament_id"], season_id)
    return season, events, standings

with st.sidebar:
    st.header("Filtri")
    selected = st.multiselect("Leghe", list(LEAGUES), default=list(LEAGUES))
    horizon = st.slider("Orizzonte (giorni)", 1, 60, 14)
    threshold = st.slider("Interesse minimo", 0, 100, 60)
    max_matches = st.slider("Numero massimo", 5, 50, 20)
    no_spoilers = st.toggle("Modalità senza risultati", value=True)
    if st.button("Aggiorna dati"):
        st.cache_data.clear()
        st.rerun()

now = datetime.now(tz=ROME)
cutoff = now + timedelta(days=horizon)
all_rows = []
errors = []

with st.spinner("Aggiorno calendario, classifica e forma recente…"):
    for league in selected:
        try:
            season, events, standings = load_league(league)
            ranked = ranked_upcoming(events, standings, int(now.timestamp()))
            for item in ranked:
                event = item["event"]
                kickoff = datetime.fromtimestamp(event["startTimestamp"], tz=timezone.utc).astimezone(ROME)
                if kickoff > cutoff or item["interest"] < threshold:
                    continue
                home = event.get("homeTeam", {}).get("name", "Casa")
                away = event.get("awayTeam", {}).get("name", "Trasferta")
                all_rows.append({
                    "Interesse": item["interest"],
                    "Partita": f"{home} – {away}",
                    "Lega": league,
                    "Data": kickoff,
                    "Perché": " · ".join(item["reasons"]),
                    "SofaScore": f"https://www.sofascore.com/event/{event.get('id')}",
                })
        except SofaScoreError as exc:
            errors.append(f"{league}: {exc}")

all_rows = sorted(all_rows, key=lambda r: (-r["Interesse"], r["Data"]))[:max_matches]

if errors:
    st.warning("Alcune leghe non sono state caricate:\n\n" + "\n\n".join(errors))

if not all_rows:
    st.info("Nessuna partita soddisfa i filtri attuali. Riduci la soglia o amplia l’orizzonte.")
else:
    c1, c2, c3 = st.columns(3)
    c1.metric("Partite selezionate", len(all_rows))
    c2.metric("Indice massimo", f"{all_rows[0]['Interesse']:.0f}/100")
    c3.metric("Aggiornato", now.strftime("%d/%m %H:%M"))

    for i, row in enumerate(all_rows, 1):
        with st.container(border=True):
            left, right = st.columns([5, 1])
            with left:
                st.subheader(f"{i}. {row['Partita']}")
                st.write(f"**{row['Lega']}** · {row['Data'].strftime('%a %d %b, %H:%M')} · {row['Perché']}")
                st.link_button("Apri su SofaScore", row["SofaScore"])
            with right:
                st.metric("Interesse", f"{row['Interesse']:.0f}/100")

    csv_rows = [{**r, "Data": r["Data"].isoformat()} for r in all_rows]
    st.download_button(
        "Scarica CSV", pd.DataFrame(csv_rows).to_csv(index=False).encode("utf-8"),
        file_name="match_radar.csv", mime="text/csv"
    )

    if telegram_configured():
        if st.button("Invia la selezione su Telegram"):
            lines = ["⚽ Match Radar"]
            for row in all_rows[:10]:
                lines.append(
                    f"{row['Interesse']:.0f}/100 — {row['Partita']}\n"
                    f"{row['Data'].strftime('%d/%m %H:%M')} · {row['Lega']}"
                )
            send_telegram("\n\n".join(lines))
            st.success("Messaggio inviato.")
    else:
        st.caption("Per le notifiche Telegram, compila TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID nel file .env.")

with st.expander("Come viene calcolato l’indice?"):
    st.markdown("""
L’indice combina: qualità delle squadre (29%), equilibrio (23%), forma nelle ultime 5 (17%),
potenziale offensivo (13%), importanza di classifica (10%) e rivalità/derby (8%).
È un criterio editoriale, non una previsione di risultato.
""")

st.caption("Uso personale. L’API SofaScore impiegata non è documentata pubblicamente e può cambiare.")
