# Match Radar — Top 5 leghe

Piccola app Streamlit che legge calendario, risultati e classifiche da SofaScore e ordina le prossime partite per interesse.

## Funzioni

- Premier League, LaLiga, Serie A, Bundesliga e Ligue 1
- rilevamento automatico della stagione più recente
- storico dall'inizio della stagione per calcolare forma e profilo offensivo
- indice di interesse 0–100 con motivazioni
- filtri per lega, giorni, soglia e quantità
- link alla scheda SofaScore ed export CSV
- invio manuale della selezione su Telegram (opzionale)

## Avvio

Richiede Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # Windows: copy .env.example .env
streamlit run app.py
```

Apri l'indirizzo mostrato da Streamlit, normalmente `http://localhost:8501`.

## Telegram opzionale

1. Crea un bot tramite BotFather.
2. Inserisci token e chat ID nel file `.env`.
3. Riavvia l'app e usa il pulsante “Invia la selezione su Telegram”.

## Nota sull'integrazione

SofaScore non espone, per questo caso d'uso, una API pubblica documentata con garanzie di stabilità. Il client usa endpoint web non documentati, applica cache e limita le richieste. Gli endpoint possono cambiare o diventare non disponibili. Prima di pubblicare o monetizzare l'app, verifica i termini applicabili e valuta un data provider con licenza.

## Personalizzazione

- pesi dell'indice: `src/ranking.py`
- rivalità: `src/config.py`
- leghe e ID torneo: `src/config.py`
- durata cache: decoratore `@st.cache_data` in `app.py`
